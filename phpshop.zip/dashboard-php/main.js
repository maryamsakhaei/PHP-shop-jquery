$(document).ready(function() {
    $(".sib").click(function () {
        var price=5000;
        var info='summer fruite';
        $(".fruit").html("<img src='image/apple.jpg'>");
        $(".prices").html("<p>price" +price+" Erou </p>");
        $(".gheymat").val(price);
        $(".pic").val('image/apple.jpg');
        $(".information").html("<p>summer fruite</p>");
        $(".info").val(info);

    });
    $(".porteghal").click(function () {
        var price=7000;
        var info='winter fruite';
        $(".fruit").html("<img src='image/orange.jpg'>");
        $(".prices").html("<p>price" +price+" Erou </p>");
        $(".gheymat").val(price);
        $(".pic").val('image/orange.jpg');
        $(".information").html("<p>ÛŒÚ© Ù†ÙˆØ¹ Ù…ÛŒÙˆÙ‡ Ø²Ù…Ø³ØªØ§Ù†ÛŒ Ø§Ø³Øª Ú©Ù‡ Ø­Ø§ÙˆÛŒ Ø²ÛŒØ§Ø¯ÛŒ ÙˆÛŒØªØ§Ù…ÛŒÙ† Ø« Ù…ÛŒØ¨Ø§Ø´Ø¯</p>");
        $(".info").val(info);
    });
    $(".blue").click(function () {
        var price=700000;
        var info='Four Seasons.'
        $(".fruit").html("<img src='image/bluebery.jpg'>");
        $(".prices").html("<p>price" +price+" Erou </p>");
        $(".gheymat").val(price);
        $(".pic").val('image/bluebery.jpg');
        $(".information").html("<p>Four Seasons.</p>");
        $(".info").val(info);
    });
    $(".shatoot").click(function () {
         var price=700000;
        var info='summer fruite';
        $(".fruit").html("<img src='image/shatoot.jpg'>");
        $(".prices").html("<p>price" +price+" Erou </p>");
        $(".gheymat").val(price);
        $(".pic").val('image/shatoot.jpg');
        $(".information").html("<p>summer fruite.</p>");
        $(".info").val(info);
    });
    $(".khiar").click(function () {
        var price=20000;
        var info='Four Seasons';
        $(".fruit").html("<img src='image/cucumber.jpg'>");
        $(".prices").html("<p>price" +price+" Erou </p>");
        $(".gheymat").val(price);
        $(".pic").val('image/cucumber.jpg');
        $(".information").html("<p>Four Seasons </p>");
        $(".info").val(info);
    });
    $(".ezhdeha").click(function () {
        var price=550000;
        var info='Four Seasons';
        $(".fruit").html("<img src='image/ezhdeha.jpg'>");
        $(".prices").html("<p>price" +price+" Erou </p>");
        $(".gheymat").val(price);
        $(".pic").val('image/ezhdeha.jpg');
        $(".information").html("<p>Four Seasons. </p>");
        $(".info").val(info);
       
    });
    $(".holo").click(function () {
        var price=80000;
        var info='summer fruite';
        $(".fruit").html("<img src='image/holo.jpg'>");
        $(".prices") .html("<p>price" +price+" Erou </p>");
        $(".gheymat").val(price);
        $(".pic").val('image/holo.jpg');
        $(".information").html
        ("<p> summer fruite </p>");
        $(".info").val(info);
    });
    $(".toot").click(function () {
        var price=150000;
        var info='summer fruite';
        $(".fruit").html("<img src='image/toot.jpg'>");
        $(".prices").html("<p>price" +price+" Erou </p>");
        $(".gheymat").val(price);
        $(".pic").val('image/toot.jpg');
        $(".information").html
        ("<p>summer fruite </p>");
        $(".info").val(info);
    });
    $(".anar").click(function () {
        var price=150000;
        var info='autumn fruite ';
        $(".fruit").html("<img src='image/anarr.jpg'>");
        $(".prices").html("<p>price" +price+" Erou </p>");
        $(".gheymat").val(price);
        $(".pic").val('image/anarr.jpg');
        $(".information").html
        ("<p> autumn fruite</p>");
        $(".info").val(info);
    });
});
